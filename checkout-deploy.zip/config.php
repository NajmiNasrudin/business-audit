<?php
define('TOYYIBPAY_SECRET_KEY',   '4eauop47-idz8-lkbd-j9nx-5q84zwgkjbfn');
define('TOYYIBPAY_CATEGORY_CODE', 'r4i8vc39');
define('TOYYIBPAY_BASE_URL',      'https://toyyibpay.com');
define('SITE_URL',                'https://bizbuddyhq.com/checkout');
define('LOG_FILE',                __DIR__ . '/orders.csv');

$PRODUCTS = [
    'audit-lite' => [
        'id'          => 'audit-lite',
        'name'        => 'Audit Lite',
        'price'       => 497,
        'description' => 'Remote diagnostic bisnes anda — 5 pillar framework, report PDF, action plan 90 hari.',
        'available'   => true,
    ],
    'product-2' => [
        'id'          => 'product-2',
        'name'        => 'Coming Soon',
        'price'       => 0,
        'description' => '',
        'available'   => false,
    ],
    'product-3' => [
        'id'          => 'product-3',
        'name'        => 'Coming Soon',
        'price'       => 0,
        'description' => '',
        'available'   => false,
    ],
];
