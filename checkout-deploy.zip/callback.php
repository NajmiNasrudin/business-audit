<?php
require_once __DIR__ . '/config.php';

// ToyyibPay sends callback as POST form fields
$order_ref   = $_POST['billExternalReferenceNo'] ?? '';
$purchase_id = $_POST['billCode']               ?? '';
$status_code = $_POST['status_id']              ?? '';
$amount      = ($_POST['billpaymentAmount']      ?? 0);
$client_name = $_POST['billTo']                 ?? '';
$client_email= $_POST['billEmail']              ?? '';
$currency    = 'MYR';

// ToyyibPay status: 1=success, 2=pending, 3=fail
$status = match($status_code) { '1' => 'PAID', '2' => 'PENDING', '3' => 'FAILED', default => 'UNKNOWN' };

if (!$order_ref) {
    http_response_code(400);
    exit;
}

// Log callback
$log_row = [
    date('Y-m-d H:i:s'),
    $order_ref,
    $purchase_id,
    $client_name,
    $client_email,
    $currency . number_format($amount, 2),
    strtoupper($status),
];

$log_line = implode(',', array_map(fn($v) => '"' . str_replace('"', '""', $v) . '"', $log_row)) . "\n";
$callback_log = __DIR__ . '/payments.csv';

if (!file_exists($callback_log)) {
    file_put_contents($callback_log, '"Date","Order Ref","Purchase ID","Name","Email","Amount","Status"' . "\n");
}
file_put_contents($callback_log, $log_line, FILE_APPEND | LOCK_EX);

http_response_code(200);
echo 'OK';
