<?php
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

// Sanitize inputs
$product_id    = trim($_POST['product_id']    ?? '');
$name          = trim($_POST['name']          ?? '');
$email         = trim($_POST['email']         ?? '');
$phone         = trim($_POST['phone']         ?? '');
$business_name = trim($_POST['business_name'] ?? '');
$business_type = trim($_POST['business_type'] ?? '');

// Validate product
if (!isset($PRODUCTS[$product_id]) || !$PRODUCTS[$product_id]['available']) {
    die('Produk tidak sah.');
}

$product = $PRODUCTS[$product_id];

// Validate required fields
if (!$name || !$email || !$phone || !$business_name) {
    header('Location: index.php?error=incomplete');
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: index.php?error=email');
    exit;
}

// Generate order reference
$order_ref = strtoupper(substr($product_id, 0, 2)) . '-' . date('ymdHi') . '-' . rand(100, 999);

// Amount in cents
$amount_cents = $product['price'] * 100;

// Clean phone number
$phone_clean = preg_replace('/\D/', '', $phone);

// ToyyibPay API payload
$payload = [
    'userSecretKey'          => TOYYIBPAY_SECRET_KEY,
    'categoryCode'           => TOYYIBPAY_CATEGORY_CODE,
    'billName'               => $product['name'],
    'billDescription'        => 'Bisnes: ' . $business_name . ($business_type ? ' (' . $business_type . ')' : '') . ' | Ref: ' . $order_ref,
    'billPriceSetting'       => 1,
    'billPayorInfo'          => 1,
    'billAmount'             => $amount_cents,
    'billReturnUrl'          => SITE_URL . '/thank-you.php',
    'billCallbackUrl'        => SITE_URL . '/callback.php',
    'billExternalReferenceNo'=> $order_ref,
    'billTo'                 => $name,
    'billEmail'              => $email,
    'billPhone'              => $phone_clean,
    'billSplitPayment'       => 0,
    'billSplitPaymentArgs'   => '',
    'billPaymentChannel'     => 0,
    'billContentEmail'       => 'Terima kasih kerana memilih ' . $product['name'] . '. Kami akan hubungi anda dalam 24 jam.',
    'billChargeToCustomer'   => 1,
];

// Call ToyyibPay API
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, TOYYIBPAY_BASE_URL . '/index.php/api/createBill');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
$response = curl_exec($ch);
$curl_error = curl_error($ch);
curl_close($ch);

if ($curl_error || !$response) {
    error_log('ToyyibPay curl error: ' . $curl_error);
    header('Location: cancel.php?reason=api_error');
    exit;
}

$result = json_decode($response, true);

if (!isset($result[0]['BillCode'])) {
    error_log('ToyyibPay error: ' . $response);
    header('Location: cancel.php?reason=bill_error');
    exit;
}

$bill_code = $result[0]['BillCode'];

// Log order
$log_row = [
    date('Y-m-d H:i:s'),
    $order_ref,
    $bill_code,
    $product['name'],
    'RM' . $product['price'],
    $name,
    $email,
    $phone,
    $business_name,
    $business_type,
    'PENDING',
];

$log_line = implode(',', array_map(fn($v) => '"' . str_replace('"', '""', $v) . '"', $log_row)) . "\n";

if (!file_exists(LOG_FILE)) {
    file_put_contents(LOG_FILE, '"Date","Order Ref","Bill Code","Product","Amount","Name","Email","Phone","Business","Type","Status"' . "\n");
}
file_put_contents(LOG_FILE, $log_line, FILE_APPEND | LOCK_EX);

// Redirect to ToyyibPay checkout
header('Location: ' . TOYYIBPAY_BASE_URL . '/' . $bill_code);
exit;
